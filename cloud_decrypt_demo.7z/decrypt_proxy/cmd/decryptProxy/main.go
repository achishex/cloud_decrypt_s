package main

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"decryptServerProxy/internal/balanceManger"
	"decryptServerProxy/internal/config"
	"decryptServerProxy/internal/router"
	"github.com/go-micro/plugins/v4/server/http"

	"fmt"
	"go-micro.dev/v4"
	"go-micro.dev/v4/server"
	"os"
	"os/signal"
	"syscall"
	"time"
)

var (
	TestDefaultConfigPath string = "D:\\works\\decryptServerProxy\\config\\application-dev.yml"
	TestDefaultDirectory  string = "D:\\works\\decryptServerProxy\\logs\\decrypt-proxy-server"
)

func main() {
	//1. 初始化 配置
	//2. 读取配置，获取ip,和端口
	//3. 初始化http 路由.注册回调函数
	//4.  启动服务

	var (
		defaultConfigPath   = "config/application-dev.yml" // "/opt/cloud/service/decrypt-proxy-service/config/application-dev.yml"
		defaultLogDirectory = "logs/decrypt-proxy-service" //"/logs/ms_log/decrypt-proxy-service"
	)

	config.InitLog(defaultConfigPath, defaultLogDirectory)
	config.InitConfig(defaultConfigPath)

	httpServer := http.NewServer(
		server.Name("decryptServerProxy"),
		server.Address(fmt.Sprintf("0.0.0.0:%v", config.GetConfig().ConnectPort.HttpServerPort)),
		server.Version("v1.0.0"))

	err := httpServer.Handle(httpServer.NewHandler(router.GetProxyHttpRouter().GetMux()))
	if err != nil {
		logger.Errorf("add register http server to go-micro fail.")
		return
	}

	router.RegisterRouter()

	microServer := micro.NewService(micro.Server(httpServer))
	microServer.Init()

	ctx, cancel := context.WithCancel(context.Background())
	go func() {
		balanceManger.GetBalanceMngInst().DialCheck(ctx)
	}()

	go func() {
		if err := microServer.Run(); err != nil {
			fmt.Printf("start micro server fail, err: %v", err)
			cancel()
		}
	}()

	signalCh := make(chan os.Signal, 1)
	signal.Notify(signalCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case <-signalCh:
		logger.Infof("receive stop signal.")
	case <-ctx.Done():
		logger.Infof("receive http start fail.")
	}
	cancel()

	fmt.Println("receive stop signal notify.")
	tmCtx, timeCancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer timeCancel()
	var stopChan chan bool = make(chan bool)
	defer close(stopChan)
	go func() {
		httpServer.Stop()
		stopChan <- true
	}()

	select {
	case <-tmCtx.Done():
		logger.Infof("wait 1second to stop")
	case <-stopChan:
		logger.Infof("http server stop ok!")
	}
	logger.Infof("end stop http server.")
}
