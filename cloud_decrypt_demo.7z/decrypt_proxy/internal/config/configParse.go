package config

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"fmt"
	"github.com/go-yaml/yaml"
	"io/ioutil"
	"os"
)

var ServiceCfg *ServiceConfig

func GetConfig() *ServiceConfig {
	return ServiceCfg
}

type ServiceConfig struct {
	ConnectPort struct {
		HttpServerPort int `yaml:"http-port"`
	} `yaml:"connect-port"`
	DomainName struct {
		IncDomainName    string `yaml:"inc-domain-name"`
		VendorDomainName string `yaml:"vendor-domain-name"`
		DialSecond       int    `yaml:"dial-second"`
	} `yaml:"domain-name"`
	Logger struct {
		Encoding    string `yaml:"encoding"`
		FilterTopic string `yaml:"filterTopic"`
		Level       string `yaml:"level"`
		Rotate      struct {
			Compress   bool   `yaml:"compress"`
			Filename   string `yaml:"filename"`
			Localtime  bool   `yaml:"localtime"`
			Maxage     int    `yaml:"maxage"`
			Maxbackups int    `yaml:"maxbackups"`
			Maxsize    int    `yaml:"maxsize"`
		} `yaml:"rotate"`
	} `yaml:"logger"`
}

func ParseYamlFile(filename string) (*ServiceConfig, error) {
	p, _ := os.Getwd()
	fmt.Println("pwd: ", p)
	buf, err := ioutil.ReadFile(filename)
	if err != nil {
		logger.Errorf("ReadFile: %v", err)
		return nil, err
	}
	// 初始化 ServiceCfg
	ServiceCfg = &ServiceConfig{}
	err = yaml.Unmarshal(buf, ServiceCfg)
	if err != nil {
		logger.Errorf("Unmarshal: %v", err)
		return ServiceCfg, err
	}
	logger.Info("ServiceCfg: %+v", ServiceCfg)
	return ServiceCfg, nil
}

func InitConfig(filePath string) {
	ServiceCfg, err := ParseYamlFile(filePath)
	if err != nil {
		logger.Fatalf("parseYamlFile: %v", err)
		return
	}

	if ServiceCfg == nil {
		logger.Fatalf("ServiceCfg is nil after parsing YAML file")
		return
	}

	logger.Infof("Parsed YAML file: %+v\n", ServiceCfg)
}
