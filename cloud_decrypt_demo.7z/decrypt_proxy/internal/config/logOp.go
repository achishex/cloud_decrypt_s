package config

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

func InitLog(logConfigFile string, logSiteDir string) {
	if err := logger.Init(logConfigFile, logSiteDir); err != nil {
		logger.Fatal("init log failed! errors info %s", err)
		return
	}
}
