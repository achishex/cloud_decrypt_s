package router

import (
	"decryptServerProxy/internal/decryptProxyLogic"
	"decryptServerProxy/pkg/parserWrapper"
)

// RegisterRouter 业务方的所有路由名和路由处理函数； 新增一个api， 就要添加一次。每个路由处理函数由业务服务自己定义。
func RegisterRouter() {
	parserWrapper.RegisterMux(GetProxyHttpRouter().GetMux(), "/api/login", decryptProxyLogic.LoginProxy)
	parserWrapper.RegisterMux(GetProxyHttpRouter().GetMux(), "/api/yd/decrypt", decryptProxyLogic.MsgProxy)
}
