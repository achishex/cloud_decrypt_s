package router

import (
	"decryptServerProxy/pkg/docsGenTools"
	"decryptServerProxy/pkg/singleFactory"
	"net/http"
)

type ProxyHttpRouter struct {
	mx *http.ServeMux
}

func (p *ProxyHttpRouter) GetMux() *http.ServeMux {
	return p.mx
}

var GetProxyHttpRouter = singleFactory.SingletonFactory(func(r *ProxyHttpRouter) {
	r.mx = http.NewServeMux()
	docsGenTools.InitDocsGenServerOnGinRouter(r.mx)
})
