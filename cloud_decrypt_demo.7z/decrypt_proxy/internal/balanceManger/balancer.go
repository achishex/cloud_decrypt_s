package balanceManger

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"decryptServerProxy/internal/config"
	"decryptServerProxy/pkg/singleFactory"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"sync"
	"sync/atomic"
	"time"
)

const (
	AllDisUsed            = 0
	IncDecryptDomainOk    = 1
	VendorDecryptDomainOk = 2
)

const (
	RouterInc    = 1
	RouterVendor = 2
)

type BalanceManger struct {
	DomainNameDecryptInc    string //公司的解密服务域名
	DomainNameDecryptVendor string //供应商解密服务域名
	ValidInc                int32  //是否有效，通过拨测接口来探测
	ValidVendor             int32  //是否有效，通过拨测接口来探测
	// 定时器， 拨测定时器
	tmr            *time.Timer
	dialTimeSecond int

	incCheckNotify    chan int32
	vendorCheckNotify chan int32
	DebugFlag         bool

	//TokenDomainPool 是： token 和 domain name 映射关系
	tokenDomainPool *TokenDomainPool
}

// GetBalanceMngInst 获取解密服务器后端节点的单例对象
var GetBalanceMngInst = singleFactory.SingletonFactory(func(b *BalanceManger) {
	b.DomainNameDecryptInc = config.GetConfig().DomainName.IncDomainName
	b.DomainNameDecryptVendor = config.GetConfig().DomainName.VendorDomainName
	b.dialTimeSecond = config.GetConfig().DomainName.DialSecond
	if b.dialTimeSecond <= 0 {
		b.dialTimeSecond = 5 //默认5second
	}
	//
	atomic.StoreInt32(&(b.ValidInc), 0)
	atomic.StoreInt32(&(b.ValidVendor), 0)
	b.DebugFlag = false

	b.incCheckNotify = make(chan int32, 10)
	b.vendorCheckNotify = make(chan int32, 10)

	b.tokenDomainPool = &TokenDomainPool{
		TokenDomains: make(map[string]*DomainNode),
	}
})

type TokenResponse struct {
	Success bool   `json:"success"`
	Msg     string `json:"msg"`
	Data    struct {
		Token  string   `json:"token"`
		Orders []string `json:"orders"`
	} `json:"data"`
}

type DomainNode struct {
	domainInfo  *string
	backendType int32
}

// TokenDomainPool 节点描述
type TokenDomainPool struct {
	mtx          sync.RWMutex
	TokenDomains map[string]*DomainNode
}

func (d *TokenDomainPool) findDomainNode(token *string) (*DomainNode, error) {
	if token == nil || len(*token) <= 0 {
		return nil, fmt.Errorf("token is nil")
	}

	d.mtx.RLock()
	defer d.mtx.RUnlock()

	data, ok := d.TokenDomains[*token]
	if !ok || data == nil {
		return nil, fmt.Errorf("token not found")
	}

	return &DomainNode{
		domainInfo:  data.domainInfo,
		backendType: data.backendType,
	}, nil
}
func (d *TokenDomainPool) addDomainNode(token *string, domainInfo *string, backendType int32) {
	d.mtx.Lock()
	defer d.mtx.Unlock()

	d.TokenDomains[*token] = &DomainNode{
		domainInfo:  domainInfo,
		backendType: backendType,
	}
}
func (d *TokenDomainPool) delDomainNode(token *string) {
	if token == nil || len(*token) <= 0 {
		return
	}
	d.mtx.Lock()
	defer d.mtx.Unlock()
	delete(d.TokenDomains, *token)
}

func (b *BalanceManger) dialIncDomain() bool {
	var token string
	{
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptInc).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"username": "test1",
			"password": "Misran44",
		}).Get("/api/login")

		if err != nil {
			logger.Errorf("check login api inc fail, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check login api fail inc, status code: %d", resp.StatusCode())
			return false
		}

		var response TokenResponse
		if err := json.Unmarshal(resp.Body(), &response); err != nil {
			logger.Errorf("unmarshal json fail fail inc, err: %v, response: %v", err, string(resp.Body()))
			return false
		}
		token = response.Data.Token
		if token == "" {
			logger.Errorf("token is empty")
			return false
		}

	}

	{
		a3Data := "a31343525950a8c19cf57ab83ea0295d3f97fb50157cd8ffe1e333faf1cfe4055f1b0dc029fe0994eb736704faf880abb8a8a963b40f34dcfa82b5a30c44850c7f5d6265fc54ebf5b6f1a96b52a8bfade8e5501ece9ec105a3011660ee3fb435154d7658bd3de7bda352c5b5c086c99282fd8206873406cad5b90fc9b965147bcfc22000120a5961de534382b32f653f8abd426d0c2de183c9ba2ed98bf61519788a3dc1d6220000000000000046b72d"
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptInc).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"hex":   a3Data,
			"token": token,
		}).Get("/api/yd/decrypt")

		if err != nil {
			logger.Errorf("check decrypt a3 api fail inc, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check inc decrypt a3 api http code: %v, body: %v", resp.StatusCode(), string(resp.Body()))
			return false
		}
	}

	{
		msg80 := "8010494e4650a8c19cf5a7f3ea787968eba56d00e34fb2080fe871a8fb420dc2c4a94bdf4ec78a116f69ef2cb6500805bc8f89bdbbddd4e918b250d634a38a60ebb15ed0cfb6eafce8d1095c17d10d60cd8fb8013cac105a1cd0b2e3d8dfef10468e5d4e4e34fab74f6e6957005a0ff1b9d277b62e11945280f352ec1095afff5c12c30000000000000000000000000000000000000000000000000000000000000000000000000000ac18bbd3270e73"
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptInc).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"hex":   msg80,
			"token": token,
		}).Get("/api/yd/decrypt")

		if err != nil {
			logger.Errorf("check inc decrypt 80 api fail, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check inc decrypt 80 api http code: %v, body: %v", resp.StatusCode(), string(resp.Body()))
			return false
		}
	}

	return true
}

// dialVendorDomain return valid is true, invalid is false.
func (b *BalanceManger) dialVendorDomain() bool {
	var token string
	{
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptVendor).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"username": "TC",
			"password": "abc678!!",
		}).Get("/api/login")

		if err != nil {
			logger.Errorf("check vendor login api vendor fail, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check vendor login api fail, status code: %d", resp.StatusCode())
			return false
		}

		var response TokenResponse
		if err := json.Unmarshal(resp.Body(), &response); err != nil {
			logger.Errorf("unmarshal vendor json fail fail, err: %v, response: %v", err, string(resp.Body()))
			return false
		}
		token = response.Data.Token
		if token == "" {
			logger.Errorf("vendor token is empty")
			return false
		}

	}

	{
		a3Data := "a31343525950a8c19cf57ab83ea0295d3f97fb50157cd8ffe1e333faf1cfe4055f1b0dc029fe0994eb736704faf880abb8a8a963b40f34dcfa82b5a30c44850c7f5d6265fc54ebf5b6f1a96b52a8bfade8e5501ece9ec105a3011660ee3fb435154d7658bd3de7bda352c5b5c086c99282fd8206873406cad5b90fc9b965147bcfc22000120a5961de534382b32f653f8abd426d0c2de183c9ba2ed98bf61519788a3dc1d6220000000000000046b72d"
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptVendor).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"hex":   a3Data,
			"token": token,
		}).Get("/api/yd/decrypt")

		if err != nil {
			logger.Errorf("check vendor decrypt a3 api fail, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check vendor decrypt a3 api http code: %v, body: %v", resp.StatusCode(), string(resp.Body()))
			return false
		}
	}

	{
		msg80 := "a31343525950a8c19cf57ab83ea0295d3f97fb50157cd8ffe1e333faf1cfe4055f1b0dc029fe0994eb736704faf880abb8a8a963b40f34dcfa82b5a30c44850c7f5d6265fc54ebf5b6f1a96b52a8bfade8e5501ece9ec105a3011660ee3fb435154d7658bd3de7bda352c5b5c086c99282fd8206873406cad5b90fc9b965147bcfc22000120a5961de534382b32f653f8abd426d0c2de183c9ba2ed98bf61519788a3dc1d6220000000000000046b72d"
		var cli *resty.Client
		cli = resty.New().SetBaseURL(b.DomainNameDecryptVendor).SetTimeout(3 * time.Second)
		resp, err := cli.R().SetDebug(b.DebugFlag).SetContext(context.Background()).SetQueryParams(map[string]string{
			"hex":   msg80,
			"token": token,
		}).Get("/api/yd/decrypt")

		if err != nil {
			logger.Errorf("check vendor decrypt 80 api fail, err: %v", err)
			return false
		}
		if resp.StatusCode() != 200 {
			logger.Errorf("check vendor decrypt 80 api http code: %v, body: %v", resp.StatusCode(), string(resp.Body()))
			return false
		}
	}

	return true
}

func (b *BalanceManger) doDial() {
	go func() {
		ret := b.dialIncDomain()
		if ret {
			b.incCheckNotify <- 1
		} else {
			b.incCheckNotify <- 0
		}

	}()

	go func() {
		ret := b.dialVendorDomain()
		if ret {
			b.vendorCheckNotify <- 1
		} else {
			b.vendorCheckNotify <- 0
		}
	}()
}

func (b *BalanceManger) DialCheck(ctx context.Context) {
	logger.Infof("begin to dial domain name server,check if working.")
	b.doDial()

	b.tmr = time.NewTimer(time.Duration(b.dialTimeSecond) * time.Second)
	defer func() {
		b.tmr.Stop()
		logger.Infof("stop check timer.")
	}()

	for {
		select {
		case <-b.tmr.C:
			logger.Debugf("check domain name valid work begin.")
			b.doDial()
			b.tmr.Reset(time.Duration(b.dialTimeSecond) * time.Second)
		case <-ctx.Done():
			logger.Infof("receive close signal, stop check doing.")
			return

		case checkRet, ok := <-b.incCheckNotify:
			if !ok {
				return
			}
			atomic.StoreInt32(&b.ValidInc, checkRet)
			logger.Debugf("inc check, inc decrypt server status: %v.", checkRet)

		case checkRet, ok := <-b.vendorCheckNotify:
			if !ok {
				return
			}
			atomic.StoreInt32(&b.ValidVendor, checkRet)
			logger.Debugf("vendor check, inc decrypt server status: %v.", checkRet)
		}
	}
}

// CheckDomainValid 检查 domain name 是否有效
func (b *BalanceManger) CheckDomainValid(domainName string) bool {
	if b.DomainNameDecryptVendor == domainName {
		if atomic.LoadInt32(&b.ValidVendor) > 0 {
			return true
		}
		return false
	}

	if b.DomainNameDecryptInc == domainName {
		if atomic.LoadInt32(&b.ValidInc) > 0 {
			return true
		}
		return false
	}
	return false
}

// GetValidDomainName 优先获取公司内的服务， 然后再获取其他供应商的服务。
func (b *BalanceManger) GetValidDomainName() (string, int32) {
	if atomic.LoadInt32(&b.ValidInc) > 0 {
		return b.DomainNameDecryptInc, IncDecryptDomainOk
	}

	if atomic.LoadInt32(&b.ValidVendor) > 0 {
		return b.DomainNameDecryptVendor, VendorDecryptDomainOk
	}
	return "", AllDisUsed
}

func (b *BalanceManger) GetDomainByToken(token *string) (domainName *string, domainType int32, err error) {
	if token == nil || len(*token) <= 0 {
		return nil, 0, fmt.Errorf("token is empty.")
	}

	domainNode, err := b.tokenDomainPool.findDomainNode(token)
	if err != nil || domainNode == nil {
		return nil, -1, err
	}
	return domainNode.domainInfo, domainNode.backendType, nil
}

func (b *BalanceManger) AddDomainOnToken(token *string, domainInfo *string, backendType int32) {
	b.tokenDomainPool.addDomainNode(token, domainInfo, backendType)
}

func (b *BalanceManger) DelDomainOnToken(token *string) {
	b.tokenDomainPool.delDomainNode(token)
}
