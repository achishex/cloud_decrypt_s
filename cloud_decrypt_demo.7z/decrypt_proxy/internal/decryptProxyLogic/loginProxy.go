package decryptProxyLogic

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"decryptServerProxy/internal/balanceManger"
	"fmt"
)

type LoginProxyLogin struct {
	UserName string `schema:"username"`
	Password string `schema:"password"`
}

func LoginProxy(ctx *context.Context, req *LoginProxyLogin) (*string, error) {
	if req.UserName == "" || req.Password == "" {
		logger.Errorf("request param is valid.")
		return nil, &DecryptProxyError{
			Code: 400,
			Msg:  fmt.Sprintf("request parameter wrong"),
		}
	}

	backendNode, cmpy := balanceManger.GetBalanceMngInst().GetValidDomainName()
	if backendNode == "" || cmpy == balanceManger.AllDisUsed {
		logger.Errorf("not get valid backend domain node.")
		return nil, &DecryptProxyError{
			Code: 500,
			Msg:  fmt.Sprintf("not valid backend domain node"),
		}
	}

	// 是公司账号则
	if cmpy == balanceManger.IncDecryptDomainOk {
		return TransLogin(ctx, req.UserName, req.Password, backendNode, balanceManger.RouterInc)
	}

	if cmpy == balanceManger.VendorDecryptDomainOk {
		dstAccount := UsedVendorAccount(req)
		return TransLogin(ctx, dstAccount.UserName, dstAccount.Password, backendNode, balanceManger.RouterVendor)
	}
	return nil, nil
}
