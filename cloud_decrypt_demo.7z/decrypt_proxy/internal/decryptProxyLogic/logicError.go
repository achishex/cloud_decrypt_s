package decryptProxyLogic

import "decryptServerProxy/pkg/parserWrapper"

var _ parserWrapper.CliError = (*DecryptProxyError)(nil)

type CliError interface {
	GetCode() int32
	GetCodeMsg() string
	Error() string
	GetCodeArgs() []any
}
type DecryptProxyError struct {
	Code int32
	Msg  string
}

func (d *DecryptProxyError) GetCode() int32 {
	return d.Code
}

func (d *DecryptProxyError) GetCodeMsg() string {
	return d.Msg
}

func (d *DecryptProxyError) Error() string {
	return ""
}
func (d *DecryptProxyError) GetCodeArgs() []any {
	return nil
}
