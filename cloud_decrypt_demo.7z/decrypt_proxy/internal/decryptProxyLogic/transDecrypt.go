package decryptProxyLogic

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"decryptServerProxy/internal/balanceManger"
	"decryptServerProxy/pkg/common"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"net"
	"time"
)

func UsedVendorAccount(srcReq *LoginProxyLogin) (dst *LoginProxyLogin) {
	if srcReq == nil {
		return nil
	}
	//默认是用配置的，暂时写死
	if srcReq.UserName != "TC" || srcReq.Password != "abc678!!" {
		return &LoginProxyLogin{
			UserName: "TC",
			Password: "abc678!!",
		}
	}
	return srcReq
}

func TransLogin(ctx *context.Context, userName string, passWd string, domainName string, domainType int32) (*string, error) {
	{
		var cli *resty.Client
		cli = resty.New().SetBaseURL(domainName).SetTimeout(2 * time.Second)
		resp, err := cli.R().SetDebug(false).SetContext(context.Background()).SetQueryParams(map[string]string{
			"username": userName,
			"password": passWd,
		}).Get("/api/login")

		if err != nil {
			logger.Errorf("login api type: %v, fail, err: %v", domainType, err)

			if e, ok := err.(*net.OpError); ok && e.Timeout() {
				logger.Error("Request timeout error:", err)
				return nil, &DecryptProxyError{
					Code: int32(504),
					Msg:  e.Error(),
				}
			} else if err == context.DeadlineExceeded {
				logger.Error("Context deadline exceeded:", err)
				return nil, &DecryptProxyError{
					Code: int32(504),
					Msg:  err.Error(),
				}
			} else {
				fmt.Println("Other error:", err)
				return nil, &DecryptProxyError{
					Code: int32(resp.StatusCode()),
					Msg:  resp.Status(),
				}
			}

		}

		if contentTypeData := resp.Header().Get(common.ContentTypeHeaderKey); len(contentTypeData) > 0 {
			*ctx = context.WithValue(*ctx, common.ContentTypeHeaderKey, contentTypeData)
			logger.Infof("content type value: %v", contentTypeData)
		}

		if resp.StatusCode() != 200 {
			return nil, &DecryptProxyError{
				Code: int32(resp.StatusCode()),
				Msg:  resp.Status(),
			}
		}

		var response balanceManger.TokenResponse
		if err := json.Unmarshal(resp.Body(), &response); err != nil {
			logger.Errorf("unmarshal json fail fail inc, err: %v, response: %v", err, string(resp.Body()))
			return nil, &DecryptProxyError{
				Code: 400,
				Msg:  fmt.Sprintf("%s", err.Error()),
			}
		}

		balanceManger.GetBalanceMngInst().AddDomainOnToken(&(response.Data.Token), &domainName, domainType)
		ret := string(resp.Body())
		return &(ret), nil
	}
}

func TransA3Msg(ctx *context.Context, hex string, token string, domainName string) (*string, error) {
	{
		var cli *resty.Client
		cli = resty.New().SetBaseURL(domainName).SetTimeout(1 * time.Second)
		resp, err := cli.R().SetDebug(false).SetContext(context.Background()).SetQueryParams(map[string]string{
			"hex":   hex,
			"token": token,
		}).Get("/api/yd/decrypt")

		if err != nil {
			logger.Errorf("check login api inc fail, err: %v", err)
			return nil, &DecryptProxyError{
				Code: int32(resp.StatusCode()),
				Msg:  resp.Status(),
			}
		}

		if contentTypeData := resp.Header().Get(common.ContentTypeHeaderKey); len(contentTypeData) > 0 {
			*ctx = context.WithValue(*ctx, common.ContentTypeHeaderKey, contentTypeData)
			logger.Infof("content type value: %v", contentTypeData)
		}

		if resp.StatusCode() != 200 {
			return nil, &DecryptProxyError{
				Code: int32(resp.StatusCode()),
				Msg:  resp.Status(),
			}
		}

		var response balanceManger.TokenResponse
		if err := json.Unmarshal(resp.Body(), &response); err != nil {
			logger.Errorf("unmarshal json fail fail inc, err: %v, response: %v", err, string(resp.Body()))
			return nil, &DecryptProxyError{
				Code: 400,
				Msg:  fmt.Sprintf("%s", err.Error()),
			}
		}
		ret := string(resp.Body())
		return &(ret), nil
	}
}
