package decryptProxyLogic

import (
	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
	"context"
	"decryptServerProxy/internal/balanceManger"
	"decryptServerProxy/internal/config"
	"fmt"
	"strings"
)

type MsgA3ProxyRequest struct {
	Hex   string `schema:"hex"`
	Token string `json:"token"`
}

func MsgProxy(ctx *context.Context, req *MsgA3ProxyRequest) (*string, error) {
	if req != nil {
		if strings.HasPrefix("a3", req.Hex) {
			return MsgA3Proxy(ctx, req)
		}
		return MsgA3Proxy(ctx, req)
	}
	return nil, &DecryptProxyError{
		Code: 400,
		Msg:  fmt.Sprintf("request parameter empty"),
	}
}

func MsgA3Proxy(ctx *context.Context, req *MsgA3ProxyRequest) (*string, error) {
	if req.Hex == "" || req.Token == "" {
		logger.Errorf("a3 hex or token is empty")
		return nil, &DecryptProxyError{
			Code: 400,
			Msg:  fmt.Sprintf("request parameter empty"),
		}
	}

	domainWithToken, typeWithToken, err := balanceManger.GetBalanceMngInst().GetDomainByToken(&(req.Token))
	if err != nil || domainWithToken == nil {
		return nil, &DecryptProxyError{
			Code: 400,
			Msg:  fmt.Sprintf("request parameter empty"),
		}
	}

	valid := balanceManger.GetBalanceMngInst().CheckDomainValid(*domainWithToken)
	if balanceManger.RouterInc == typeWithToken {
		if valid {
			return TransA3Msg(ctx, req.Hex, req.Token, config.GetConfig().DomainName.IncDomainName)
		}

		if vendorValid := balanceManger.GetBalanceMngInst().CheckDomainValid(config.GetConfig().DomainName.VendorDomainName); vendorValid {
			logger.Infof("is inc serving, but is invalid and vendor is valid. need to trans vendor domain, send 401 to login again.")
			balanceManger.GetBalanceMngInst().DelDomainOnToken(&(req.Token))
			return nil, &DecryptProxyError{
				Code: 401,
				Msg:  fmt.Sprintf("redirect vendor decrypt server."),
			}
		}

		return nil, &DecryptProxyError{
			Code: 502,
			Msg:  fmt.Sprintf("redirect vendor decrypt server."),
		}
	}

	if balanceManger.RouterVendor == typeWithToken {
		incValid := balanceManger.GetBalanceMngInst().CheckDomainValid(config.GetConfig().DomainName.IncDomainName)
		if incValid == false {
			return TransA3Msg(ctx, req.Hex, req.Token, config.GetConfig().DomainName.VendorDomainName)
		}
		balanceManger.GetBalanceMngInst().DelDomainOnToken(&(req.Token))
		return nil, &DecryptProxyError{
			Code: 401,
			Msg:  fmt.Sprintf("redirect inc decrypt server."),
		}
	}

	return nil, &DecryptProxyError{
		Code: 502,
		Msg:  fmt.Sprintf("not exist valid server."),
	}
}
