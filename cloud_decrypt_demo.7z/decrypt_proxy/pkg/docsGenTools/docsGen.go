package docsGenTools

import (
	"fmt"
	ginSwagger "github.com/swaggo/gin-swagger"

	_ "decryptServerProxy/pkg/docsGenTools/docs"
	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	"net/http"
	"time"
)

// InitDocsGenServerOnGin 创建一个 api doc on gin server.
func InitDocsGenServerOnGin(port int) {
	r := gin.Default()
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	endPoint := fmt.Sprintf(":%d", port)
	go func() {
		server := &http.Server{
			Addr:           endPoint,
			Handler:        r,
			ReadTimeout:    5 * time.Second,
			WriteTimeout:   5 * time.Second,
			MaxHeaderBytes: 50 * 1024 * 1024,
		}
		server.ListenAndServe()
	}()
}

func InitDocsGenServerOnGinRouter(m *http.ServeMux) *gin.Engine {
	r := gin.Default()
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	m.Handle("/", r)
	return r
}
