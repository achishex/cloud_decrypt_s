package common

const (
	XLanguageHeaderKey   = "Language"
	ContentTypeHeaderKey = "Content-Type"
	ContentTypeJson      = "application/json"
	LanguageZhCN         = "zh-CN"
	LanguageEn           = "en"

	UavWhitelistCachePrefix = "cloud_uav_whitelist:"
	EffectStatus            = 1
	DeleteStatus            = 2

	TrackS3FilePathPrefix = "cloud/track/"
)
