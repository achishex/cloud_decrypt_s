package common

import (
	"context"
	mock "decryptServerProxy/pkg/logicLog"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// request info
type DemoGetDevListReqItem struct {
	// c2 sn list ,为空时查全部
	C2SnList []string `json:"c2SnList"`
	// device sn list 为空时查全部
	EquipSnList []string `json:"equipSnList"`
	// tb code
	TbCode string `json:"tbCode"`
	// 名称或列表模糊查询值
	SearchValue string `json:"searchValue"`
}
type DemoGetDevListReq struct {
	PageIndex uint32                 `json:"pageIndex"`
	PageSize  uint32                 `json:"pageSize"`
	Data      *DemoGetDevListReqItem `json:"data"`
}

// deviceListItem //response
type deviceListItem struct {
	ID             int64  `json:"id"`
	C2SN           string `json:"c2Sn"`
	C2Name         string `json:"c2Name"`
	Name           string `json:"name"`
	Sn             string `json:"sn"`
	Etype          string `json:"etype"`
	Enable         int32  `json:"enable"`
	Online         int32  `json:"online"`
	Electricity    int32  `json:"electricity"`
	WorkStatus     int32  `json:"workStatus"`
	RadarRelevance int32  `json:"radarRelevance"`
	ParentSn       string `json:"parentSn"`
}

type DemoGetDevListRespItem struct {
	ItemDataList []deviceListItem `json:"data"`
	Total        int32            `json:"total"`
	PageIndex    int32            `json:"pageIndex"`
	PageSize     int32            `json:"pageSize"`
}
type DemoGetDevListResponse struct {
	ErrCode    int32                  `json:"errorCode"`
	ErrMessage string                 `json:"errorMessage"`
	Data       DemoGetDevListRespItem `json:"data"`
}

func TestHttpClientCall(t *testing.T) {
	mock.LoggerMock()
	req := &DemoGetDevListReq{
		PageIndex: 0,
		PageSize:  10,
		Data: &DemoGetDevListReqItem{
			//C2SnList: []string{"1272319625259778048"},
			// device sn list 为空时查全部
			//EquipSnList: []string{"STP100A01Q082014"},
			// tb code
			TbCode: "000001",
		},
	}
	reqBuf, err := json.Marshal(&req)
	if err != nil {
		t.Logf("format json fail, req: %+v, err: %v", req, err)

	}
	url := "http://cn.cloud-dev.skyfend.com:8891/inner/rest/v1/access/equip/list"
	//url := "http://cuav-cloud-service:8891/inner/rest/v1/access/equip/list"
	response, err := HttpClientCall[DemoGetDevListResponse](context.Background(), reqBuf, WithUrl(url),
		WithTimeOut(1*time.Millisecond), WithHeaders(map[string]string{"Content-Type": "application/json"}))
	//
	if err != nil || response == nil {
		t.Logf("http request fail, e: %v", err)
	} else {
		t.Logf("reponse data: %+v", response)
	}

	var httpClientHandle = HttpClientCallTpl[DemoGetDevListReq, DemoGetDevListResponse]
	response, err = httpClientHandle(context.Background(), req, WithUrl(url), WithTimeOut(100*time.Millisecond),
		WithHeaders(map[string]string{"Content-Type": "application/json"}))
	if err != nil || response == nil {
		t.Logf("http request fail, e: %v", err)
	} else {
		t.Logf("tpl, reponse data: %+v", response)
		t.Logf("code: %v, message: %v", response.ErrCode, response.ErrMessage)

		data := response.Data
		t.Logf("pageIndex: %v, pageSize: %v, total: %v", data.PageIndex, data.PageSize, data.Total)
		devLists := data.ItemDataList
		for _, dev := range devLists {
			t.Logf("device detail: %+v", dev)
		}
	}
}

func TestMockHttpClientToServer(t *testing.T) {
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t.Logf("Method: %v", r.Method)
		t.Logf("Path: %v", r.URL.Path)
		t.Logf("Content-Type: %v", r.Header.Get(http.CanonicalHeaderKey("Content-Type")))

		if r.Method == "GET" {
			//if r.URL.Path == "/profile" {
			//	// 004DDB79-6801-4587-B976-F093E6AC44FF
			//	auth := r.Header.Get("Authorization")
			//	t.Logf("Bearer Auth: %v", auth)
			//
			//	w.Header().Set(http.CanonicalHeaderKey("Content-Type"), "application/json; charset=utf-8")
			//
			//	if !strings.HasPrefix(auth, "Bearer ") {
			//		w.Header().Set("Www-Authenticate", "Protected Realm")
			//		w.WriteHeader(http.StatusUnauthorized)
			//		_, _ = w.Write([]byte(`{ "id": "unauthorized", "message": "Invalid credentials" }`))
			//
			//		return
			//	}
			//
			//	if auth[7:] == "004DDB79-6801-4587-B976-F093E6AC44FF" || auth[7:] == "004DDB79-6801-4587-B976-F093E6AC44FF-Request" {
			//		_, _ = w.Write([]byte(`{ "id": "success", "message": "login successful" }`))
			//	}
			//}

			return
		}

		if r.Method == "POST" {
			if r.URL.Path == "/login" {
				//auth := r.Header.Get("Authorization")
				//t.Logf("Basic Auth: %v", auth)

				w.Header().Set(http.CanonicalHeaderKey("Content-Type"), "application/json; charset=utf-8")

				//password, err := base64.StdEncoding.DecodeString(auth[6:])
				//if err != nil || string(password) != "myuser:basicauth" {
				//	w.Header().Set("Www-Authenticate", "Protected Realm")
				//	w.WriteHeader(http.StatusUnauthorized)
				//	_, _ = w.Write([]byte(`{ "id": "unauthorized", "message": "Invalid credentials" }`))
				//
				//	return
				//}

				time.Sleep(100 * time.Millisecond)

				_, _ = w.Write([]byte(`{ "id": "success", "message": "login successful" }`))
			}

			return
		}
	})
	var httpServer *httptest.Server
	if false {
		httpServer = httptest.NewTLSServer(handler)
	}
	httpServer = httptest.NewServer(handler)
	defer httpServer.Close()
	//

	mock.LoggerMock()
	req := &DemoGetDevListReq{
		PageIndex: 0,
		PageSize:  10,
		Data: &DemoGetDevListReqItem{
			C2SnList: []string{"1272319625259778048"},
			// device sn list 为空时查全部
			EquipSnList: []string{"STP100A01Q082014"},
			// tb code
			TbCode: "000001",
		},
	}

	var httpClientHandle = HttpClientCallTpl[DemoGetDevListReq, DemoGetDevListResponse]
	response, err := httpClientHandle(context.Background(), req, WithUrl("/login"), WithTimeOut(103*time.Millisecond), WithBaseUrl(httpServer.URL))
	if err != nil {
		t.Logf("http request, err: %v", err)
	} else {
		t.Logf("succ: %v", response)
	}
}
