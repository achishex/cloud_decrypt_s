package common

import (
	"encoding/json"
	"errors"
	"net/http"

	logger "adasgitlab.autel.com/tools/cuav_plugin/log"
)

type TokenPayload struct {
	Iat       int64             `json:"iat"`
	Exp       int64             `json:"exp"`
	Tid       string            `json:"tid"`
	Uid       int64             `json:"uid"`
	Account   string            `json:"account"`
	AccountId int64             `json:"accountId"`
	TbCode    string            `json:"tbCode"`
	KpiId     int64             `json:"kpiId"`
	CType     int               `json:"cType"`
	Sid       string            `json:"sid"`
	Extra     map[string]string `json:"extra"`
}

type TokenContext struct {
	NeedRenewal bool         `json:"needRenewal"`
	LoginUrl    bool         `json:"loginUrl"`
	Payload     TokenPayload `json:"payload"`
	AppSecret   string       `json:"appSecret"`
	IsDebug     string       `json:"isDebug"`
}

func GetTokenPayload(r *http.Request) (*TokenContext, error) {
	//logger.Info(r.Header)
	value := r.Header.Get("x-token-payload")
	//logger.Info("token payload: ", value)
	if value == "" {
		logger.Error("token payload is empty")
		return nil, errors.New("token payload is empty")
	}
	var tokenContext TokenContext
	err := json.Unmarshal([]byte(value), &tokenContext)
	if err != nil {
		return nil, err
	}
	return &tokenContext, nil
}
