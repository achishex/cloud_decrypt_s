package common

const (
	ContentTypeFieldName = "Content-Type"
	StatusCodeName       = "Status Code"
)
