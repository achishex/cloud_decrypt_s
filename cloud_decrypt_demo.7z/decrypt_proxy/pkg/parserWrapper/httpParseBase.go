package parserWrapper

import (
	"context"
	"net/http"
)

func Register[In any, Out any](url string, call func(ctx *context.Context, inParam In) (Out, error)) {
	http.HandleFunc(url, AccessDecorator(call))
}

func RegisterNoOut[In any](url string, call func(ctx *context.Context, inParam In) error) {
	http.HandleFunc(url, AccessDecorator(call))
}

func RegisterNoOutForm[In any](url string, call func(ctx *context.Context, inParam In) error) {
	http.HandleFunc(url, AccessFormDecorator(call))
}

func RegisterForm[In any, Out any](url string, call func(ctx *context.Context, inParam In) (Out, error)) {
	http.HandleFunc(url, AccessFormDecorator(call))
}

// //
func RegisterMux[In any, Out any](mux *http.ServeMux, url string, call func(ctx *context.Context, inParam In) (Out, error)) {
	if mux != nil {
		mux.HandleFunc(url, AccessDecorator(call))
	} else {
		http.HandleFunc(url, AccessDecorator(call))
	}
}

func RegisterNoOutMux[In any](mux *http.ServeMux, url string, call func(ctx *context.Context, inParam In) error) {
	if mux != nil {
		mux.HandleFunc(url, AccessDecorator(call))
	} else {
		http.HandleFunc(url, AccessDecorator(call))
	}

}

func RegisterNoOutFormMux[In any](mux *http.ServeMux, url string, call func(ctx *context.Context, inParam In) error) {
	if mux != nil {
		mux.HandleFunc(url, AccessFormDecorator(call))
	} else {
		http.HandleFunc(url, AccessFormDecorator(call))
	}
}
func RegisterFormMux[In any, Out any](mux *http.ServeMux, url string, call func(ctx *context.Context, inParam In) (Out, error)) {
	if mux != nil {
		mux.HandleFunc(url, AccessFormDecorator(call))
	} else {
		http.HandleFunc(url, AccessFormDecorator(call))
	}
}
